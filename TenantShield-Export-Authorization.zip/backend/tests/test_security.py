import os
os.environ["DATABASE_URL"] = "sqlite:///./test_tenantshield.db"
os.environ["JWT_SECRET"] = "test-secret"
from fastapi.testclient import TestClient
from app.main import app
from app.database import Base, engine, SessionLocal
from app.main import seed_demo_data

Base.metadata.drop_all(bind=engine)
Base.metadata.create_all(bind=engine)
with SessionLocal() as db:
    seed_demo_data(db)
client = TestClient(app)

def token(email):
    r = client.post("/api/auth/login", json={"email": email, "password": "DemoPass123!"})
    assert r.status_code == 200
    return r.json()["access_token"]

def test_tenant_a_does_not_see_tenant_b():
    r = client.get("/api/records", headers={"Authorization": f"Bearer {token('admin@college-a.demo')}"})
    assert r.status_code == 200
    assert all(x["student_code"].startswith("A-") for x in r.json())

def test_viewer_cannot_export():
    r = client.post("/api/exports/csv", headers={"Authorization": f"Bearer {token('viewer@college-a.demo')}"})
    assert r.status_code == 403

def test_admin_export_is_scoped_even_if_tenant_header_is_spoofed():
    r = client.post("/api/exports/csv", headers={
        "Authorization": f"Bearer {token('admin@college-a.demo')}",
        "X-Tenant-ID": "college-b"
    })
    assert r.status_code == 200
    assert b"A-1001" in r.content
    assert b"B-2001" not in r.content
