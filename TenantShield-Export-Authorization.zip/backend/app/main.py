import csv
import io
import os
from datetime import datetime, timezone
from fastapi import FastAPI, Depends, HTTPException, Header, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session
from sqlalchemy import select, desc, func
import jwt
from openpyxl import Workbook

from .database import Base, engine, get_db, SessionLocal
from .models import User, StudentRecord, AuditEvent
from .security import verify_password, create_access_token, decode_access_token, hash_password

app = FastAPI(
    title="TenantShield API",
    description="Tenant-aware data export authorization and audit trail for a multi-tenant SaaS demo.",
    version="1.0.0",
)
origins = os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in origins],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
bearer = HTTPBearer(auto_error=False)

EXPORT_ROLES = {"tenant_admin", "data_manager"}

def seed_demo_data(db: Session):
    if db.scalar(select(func.count()).select_from(User)):
        return
    demo_users = [
        ("admin@college-a.demo", "Aarav Sharma", "college-a", "tenant_admin"),
        ("manager@college-a.demo", "Diya Patel", "college-a", "data_manager"),
        ("viewer@college-a.demo", "Kabir Rao", "college-a", "viewer"),
        ("admin@college-b.demo", "Ananya Reddy", "college-b", "tenant_admin"),
    ]
    for email, name, tenant, role in demo_users:
        db.add(User(email=email, full_name=name, tenant_id=tenant, role=role,
                    password_hash=hash_password("DemoPass123!"), active=True))
    records = [
        ("college-a", "A-1001", "Ishaan Kumar", "Computer Science", 2, 94),
        ("college-a", "A-1002", "Meera Singh", "Information Technology", 3, 91),
        ("college-a", "A-1003", "Arjun Das", "Electronics", 1, 88),
        ("college-a", "A-1004", "Sara Khan", "Computer Science", 4, 97),
        ("college-a", "A-1005", "Rohan Iyer", "Mechanical", 2, 84),
        ("college-b", "B-2001", "Nisha Verma", "Business", 2, 90),
        ("college-b", "B-2002", "Aditya Nair", "Computer Science", 3, 93),
        ("college-b", "B-2003", "Tara Joshi", "Design", 1, 86),
    ]
    for tenant, code, name, dept, year, attendance in records:
        db.add(StudentRecord(tenant_id=tenant, student_code=code, student_name=name,
                             department=dept, year=year, attendance_percent=attendance))
    db.commit()

@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)
    if os.getenv("SEED_DEMO_DATA", "true").lower() == "true":
        with SessionLocal() as db:
            seed_demo_data(db)

def current_user(
    credentials: HTTPAuthorizationCredentials = Depends(bearer),
    db: Session = Depends(get_db),
):
    if not credentials:
        raise HTTPException(status_code=401, detail="Bearer token required")
    try:
        payload = decode_access_token(credentials.credentials)
        user_id = int(payload["sub"])
    except (jwt.PyJWTError, ValueError, KeyError):
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    user = db.get(User, user_id)
    if not user or not user.active:
        raise HTTPException(status_code=401, detail="User is inactive or does not exist")
    return user

def write_audit(db, user, action, outcome, details="", export_format=""):
    db.add(AuditEvent(
        actor_email=user.email if user else "anonymous",
        tenant_id=user.tenant_id if user else "unknown",
        action=action, outcome=outcome, details=details[:1000], format=export_format
    ))
    db.commit()

@app.get("/health")
def health():
    return {"status": "healthy", "service": "TenantShield API"}

@app.post("/api/auth/login")
def login(payload: dict, db: Session = Depends(get_db)):
    email = str(payload.get("email", "")).lower().strip()
    password = str(payload.get("password", ""))
    user = db.scalar(select(User).where(User.email == email))
    if not user or not user.active or not verify_password(password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    return {"access_token": create_access_token(user), "token_type": "bearer",
            "user": {"id": user.id, "email": user.email, "full_name": user.full_name,
                     "tenant_id": user.tenant_id, "role": user.role}}

@app.get("/api/me")
def me(user: User = Depends(current_user)):
    return {"id": user.id, "email": user.email, "full_name": user.full_name,
            "tenant_id": user.tenant_id, "role": user.role}

@app.get("/api/dashboard")
def dashboard(db: Session = Depends(get_db), user: User = Depends(current_user)):
    # Tenant scope is derived from authenticated user, never from request parameters.
    total_records = db.scalar(select(func.count()).select_from(StudentRecord).where(StudentRecord.tenant_id == user.tenant_id)) or 0
    total_audits = db.scalar(select(func.count()).select_from(AuditEvent).where(AuditEvent.tenant_id == user.tenant_id)) or 0
    blocked = db.scalar(select(func.count()).select_from(AuditEvent).where(
        AuditEvent.tenant_id == user.tenant_id, AuditEvent.outcome == "DENIED")) or 0
    recent = db.scalars(select(AuditEvent).where(AuditEvent.tenant_id == user.tenant_id).order_by(desc(AuditEvent.id)).limit(8)).all()
    return {
        "tenant_id": user.tenant_id,
        "role": user.role,
        "records_available": total_records,
        "audit_events": total_audits,
        "blocked_attempts": blocked,
        "export_allowed": user.role in EXPORT_ROLES,
        "recent_events": [
            {"id": e.id, "occurred_at": e.occurred_at.isoformat() if e.occurred_at else "",
             "actor_email": e.actor_email, "action": e.action, "outcome": e.outcome,
             "details": e.details, "format": e.format} for e in recent
        ]
    }

@app.get("/api/records")
def list_records(db: Session = Depends(get_db), user: User = Depends(current_user)):
    rows = db.scalars(select(StudentRecord).where(StudentRecord.tenant_id == user.tenant_id).order_by(StudentRecord.id)).all()
    return [{"student_code": r.student_code, "student_name": r.student_name, "department": r.department,
             "year": r.year, "attendance_percent": r.attendance_percent} for r in rows]

@app.post("/api/exports/{export_format}")
def export_records(
    export_format: str,
    db: Session = Depends(get_db),
    user: User = Depends(current_user),
    x_tenant_id: str | None = Header(default=None),
):
    # The header is deliberately never used to determine tenant scope.
    if export_format not in {"csv", "xlsx"}:
        raise HTTPException(status_code=400, detail="Supported formats: csv, xlsx")
    if user.role not in EXPORT_ROLES:
        write_audit(db, user, "DATA_EXPORT", "DENIED", f"Role '{user.role}' is not allowed to export.", export_format)
        raise HTTPException(status_code=403, detail="Export permission required. Contact your tenant administrator.")
    rows = db.scalars(select(StudentRecord).where(StudentRecord.tenant_id == user.tenant_id).order_by(StudentRecord.id)).all()
    headers = ["student_code", "student_name", "department", "year", "attendance_percent"]
    values = [[r.student_code, r.student_name, r.department, r.year, r.attendance_percent] for r in rows]
    if export_format == "csv":
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        writer.writerow(headers)
        writer.writerows(values)
        content = buffer.getvalue().encode("utf-8-sig")
        media_type = "text/csv; charset=utf-8"
        filename = f"{user.tenant_id}-student-export.csv"
    else:
        wb = Workbook()
        ws = wb.active
        ws.title = "Authorized Records"
        ws.append(headers)
        for row in values:
            ws.append(row)
        stream = io.BytesIO()
        wb.save(stream)
        content = stream.getvalue()
        media_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        filename = f"{user.tenant_id}-student-export.xlsx"
    write_audit(db, user, "DATA_EXPORT", "ALLOWED", f"Exported {len(rows)} records", export_format)
    return StreamingResponse(io.BytesIO(content), media_type=media_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"',
                 "X-Exported-Record-Count": str(len(rows))})

@app.get("/api/audit")
def audit_log(limit: int = Query(default=50, ge=1, le=200), db: Session = Depends(get_db), user: User = Depends(current_user)):
    rows = db.scalars(select(AuditEvent).where(AuditEvent.tenant_id == user.tenant_id).order_by(desc(AuditEvent.id)).limit(limit)).all()
    return [{"id": e.id, "occurred_at": e.occurred_at.isoformat() if e.occurred_at else "",
             "actor_email": e.actor_email, "action": e.action, "outcome": e.outcome,
             "details": e.details, "format": e.format} for e in rows]

@app.get("/api/tenants")
def tenants(user: User = Depends(current_user)):
    # Intentionally returns only the current tenant; no cross-tenant directory leakage.
    return [{"tenant_id": user.tenant_id, "display_name": user.tenant_id.replace("-", " ").title()}]

