from pydantic import BaseModel, EmailStr, ConfigDict

class LoginRequest(BaseModel):
    email: str
    password: str

class UserView(BaseModel):
    id: int
    email: str
    full_name: str
    tenant_id: str
    role: str
    model_config = ConfigDict(from_attributes=True)
