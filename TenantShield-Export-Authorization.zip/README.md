# TenantShield — Tenant Data Export Authorization

A hackathon-ready multi-tenant SaaS security demo. It demonstrates tenant isolation, role-based export permissions, CSV/XLSX exports, audit logging, and blocked cross-tenant access attempts.

## Features
- JWT login with seeded demo users
- Multi-tenant sample student records
- Tenant-scoped data queries (tenant comes from authenticated identity, not the browser)
- RBAC: `tenant_admin`, `data_manager`, `viewer`
- CSV and XLSX export
- Export audit trail and denied-attempt logging
- Dashboard with summary metrics and recent audit events
- Docker Compose setup
- Basic automated authorization tests

## Quick start (Windows)
Requirements: Docker Desktop with Docker Compose, or Python 3.11+ if running the API locally.

1. Extract the ZIP.
2. Open PowerShell in the project folder.
3. Start the services:
   ```powershell
   docker compose up --build
   ```
4. Open the frontend at http://localhost:5173
5. API docs: http://localhost:8000/docs

### Demo accounts
All demo passwords are `DemoPass123!`

| Email | Tenant | Role |
|---|---|---|
| admin@college-a.demo | College A | tenant_admin |
| manager@college-a.demo | College A | data_manager |
| viewer@college-a.demo | College A | viewer |
| admin@college-b.demo | College B | tenant_admin |

### Suggested judging demo
1. Sign in as `admin@college-a.demo`.
2. Export College A data as CSV and XLSX.
3. Open Audit Log to show the successful export event.
4. Sign in as `viewer@college-a.demo` and show export is denied.
5. Sign in as `admin@college-a.demo`, use the API docs to attempt a request with `X-Tenant-ID: college-b`. The server ignores client tenant selection and scopes data to the signed-in user's tenant. Explain that the header is intentionally not used for authorization.
6. Show that College B admin can export only College B records.

## Architecture
- React/Vite: dashboard, login, export actions, audit log
- FastAPI: authentication, authorization, tenant-scoped query, export endpoint
- SQLite by default for easy local demo; PostgreSQL available through Docker Compose
- SQLAlchemy ORM
- JWT signed tokens
- Audit log records allowed and denied export attempts

## Security notes
This is an educational hackathon MVP, not a production-certified security product. Before production use, add HTTPS, managed secrets, refresh-token rotation/revocation, rate limits, stronger password policy, centralized monitoring, formal threat modeling, database backups, and security review. Keep tenant identity server-derived and test tenant isolation on every endpoint.
