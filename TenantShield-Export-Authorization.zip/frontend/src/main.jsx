import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { ShieldCheck, Download, FileSpreadsheet, Activity, LockKeyhole, Users, ClipboardList, LogOut, RefreshCw, CheckCircle2, XCircle, Building2, ArrowUpRight } from 'lucide-react';
import './style.css';

const API = import.meta.env.VITE_API_URL || 'http://localhost:8000';
const demoAccounts = [
  ['admin@college-a.demo', 'Tenant Admin'],
  ['manager@college-a.demo', 'Data Manager'],
  ['viewer@college-a.demo', 'Viewer'],
  ['admin@college-b.demo', 'College B Admin'],
];

function App() {
  const [token, setToken] = useState(localStorage.getItem('ts_token') || '');
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState('admin@college-a.demo');
  const [password, setPassword] = useState('DemoPass123!');
  const [dashboard, setDashboard] = useState(null);
  const [records, setRecords] = useState([]);
  const [audit, setAudit] = useState([]);
  const [page, setPage] = useState('Overview');
  const [notice, setNotice] = useState(null);
  const [busy, setBusy] = useState(false);

  async function api(path, options = {}) {
    const response = await fetch(`${API}${path}`, {
      ...options,
      headers: { ...(options.headers || {}), ...(token ? { Authorization: `Bearer ${token}` } : {}) }
    });
    if (!response.ok) {
      let msg = `Request failed (${response.status})`;
      try { const data = await response.json(); msg = data.detail || msg; } catch {}
      throw new Error(msg);
    }
    return response;
  }

  async function login(e) {
    e?.preventDefault();
    setBusy(true); setNotice(null);
    try {
      const r = await fetch(`${API}/api/auth/login`, {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({email, password})
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.detail || 'Login failed');
      localStorage.setItem('ts_token', data.access_token);
      setToken(data.access_token); setUser(data.user);
      setNotice({kind:'success', text:`Welcome, ${data.user.full_name}`});
    } catch (err) { setNotice({kind:'error', text:err.message}); }
    finally { setBusy(false); }
  }

  async function loadData(activeToken = token) {
    if (!activeToken) return;
    try {
      const headers = { Authorization: `Bearer ${activeToken}` };
      const [meRes, dashRes, recRes, auditRes] = await Promise.all([
        fetch(`${API}/api/me`, {headers}), fetch(`${API}/api/dashboard`, {headers}),
        fetch(`${API}/api/records`, {headers}), fetch(`${API}/api/audit`, {headers})
      ]);
      if ([meRes, dashRes, recRes, auditRes].some(r => r.status === 401)) throw new Error('Session expired. Please sign in again.');
      const [meData, dashData, recData, auditData] = await Promise.all([meRes.json(), dashRes.json(), recRes.json(), auditRes.json()]);
      setUser(meData); setDashboard(dashData); setRecords(recData); setAudit(auditData);
    } catch (err) {
      setNotice({kind:'error', text:err.message});
      if (String(err.message).includes('Session expired')) logout();
    }
  }

  useEffect(() => { if (token) loadData(token); }, [token]);

  function logout() {
    localStorage.removeItem('ts_token'); setToken(''); setUser(null);
    setDashboard(null); setRecords([]); setAudit([]);
  }

  async function exportFile(format) {
    setBusy(true); setNotice(null);
    try {
      const response = await api(`/api/exports/${format}`, {method:'POST'});
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `${user.tenant_id}-student-export.${format}`;
      document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
      setNotice({kind:'success', text:`${format.toUpperCase()} export created. Audit event recorded.`});
      await loadData();
    } catch (err) {
      setNotice({kind:'error', text:err.message});
      await loadData();
    } finally { setBusy(false); }
  }

  if (!token || !user) {
    return <div className="login-shell">
      <div className="login-visual">
        <div className="brand"><div className="brand-mark"><ShieldCheck size={25}/></div><span>Tenant<span className="brand-accent">Shield</span></span></div>
        <div className="hero-copy"><div className="eyebrow"><span className="pulse"></span> MULTI-TENANT SECURITY PLATFORM</div>
          <h1>Your data.<br/><em>Your boundary.</em></h1>
          <p>Secure data exports with tenant-aware access controls, transparent audit trails, and built-in protection against cross-organization data leaks.</p>
          <div className="hero-points"><span><CheckCircle2 size={17}/> Tenant isolation</span><span><CheckCircle2 size={17}/> Role-based access</span><span><CheckCircle2 size={17}/> Export audit trail</span></div>
        </div>
        <div className="visual-footer">TENANTSHIELD SECURITY SUITE <span>•</span> HACKATHON EDITION</div>
      </div>
      <div className="login-panel">
        <div className="login-top"><span>SECURE WORKSPACE</span><span className="secure-tag"><LockKeyhole size={13}/> ENCRYPTED SESSION</span></div>
        <div className="login-card"><div className="mobile-brand"><ShieldCheck/> TenantShield</div><div className="section-kicker">WELCOME BACK</div><h2>Sign in to your workspace</h2><p className="muted">Use a demo identity to explore tenant-level authorization.</p>
          {notice && <div className={`notice ${notice.kind}`}>{notice.text}</div>}
          <form onSubmit={login}><label>Email address</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/><label>Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} required/><button className="primary full" disabled={busy}>{busy?'Signing in…':'Sign in securely'} <ArrowUpRight size={17}/></button></form>
          <div className="demo-box"><div className="demo-heading"><Users size={15}/> DEMO ACCOUNTS <span>password: DemoPass123!</span></div>{demoAccounts.map(([em,role])=><button className="demo-account" key={em} onClick={()=>{setEmail(em);setPassword('DemoPass123!')}}><span>{em}</span><small>{role}</small></button>)}</div>
          <div className="login-note"><LockKeyhole size={14}/> Access is restricted to your assigned tenant and role.</div>
        </div>
        <div className="panel-foot">TenantShield © 2026 <span>Privacy-first by design</span></div>
      </div>
    </div>;
  }

  const allowed = ['tenant_admin','data_manager'].includes(user.role);
  const nav = [{name:'Overview',icon:Activity},{name:'Data Records',icon:FileSpreadsheet},{name:'Export Center',icon:Download},{name:'Audit Log',icon:ClipboardList}];
  return <div className="app-shell">
    <aside className="sidebar"><div className="brand"><div className="brand-mark"><ShieldCheck size={23}/></div><span>Tenant<span className="brand-accent">Shield</span></span></div>
      <div className="workspace-label">WORKSPACE</div><div className="tenant-switch"><div className="tenant-icon"><Building2 size={19}/></div><div><b>{user.tenant_id.replace('-', ' ').replace(/\b\w/g,c=>c.toUpperCase())}</b><small>Tenant workspace</small></div><span className="tenant-dot"/></div>
      <div className="nav-label">PLATFORM</div><nav>{nav.map(item=><button key={item.name} className={`nav-item ${page===item.name?'active':''}`} onClick={()=>setPage(item.name)}><item.icon size={18}/>{item.name}{item.name==='Audit Log'&&<span className="nav-count">{audit.length}</span>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="security-card"><div className="security-icon"><ShieldCheck size={19}/></div><b>Security status</b><p>Tenant isolation is active. All export requests are policy-checked.</p><span><i/> PROTECTED</span></div><div className="profile"><div className="avatar">{user.full_name.split(' ').map(n=>n[0]).slice(0,2).join('')}</div><div className="profile-info"><b>{user.full_name}</b><small>{user.role.replace('_',' ')}</small></div><button className="icon-button" title="Sign out" onClick={logout}><LogOut size={17}/></button></div></div>
    </aside>
    <main className="main-area"><header className="topbar"><div><div className="breadcrumbs">TenantShield <span>/</span> {page}</div><h1>{page==='Overview'?'Security overview':page}</h1></div><div className="top-actions"><span className="live-status"><i/> SYSTEM OPERATIONAL</span><button className="outline-button" onClick={()=>loadData()}><RefreshCw size={15}/> Refresh</button><div className="top-avatar">{user.full_name.split(' ').map(n=>n[0]).slice(0,2).join('')}</div></div></header>
      {notice && <div className={`notice app-notice ${notice.kind}`}>{notice.text}<button onClick={()=>setNotice(null)}>×</button></div>}
      {page==='Overview' && <><div className="welcome-row"><div><h2>Good to see you, {user.full_name.split(' ')[0]}.</h2><p>Here is your tenant's data security activity at a glance.</p></div><span className="date-pill"><Activity size={14}/> Live workspace</span></div>
        <div className="metric-grid"><Metric icon={FileSpreadsheet} label="Records available" value={dashboard?.records_available??'—'} foot="Scoped to your tenant" color="blue"/><Metric icon={Download} label="Export permission" value={allowed?'Granted':'Restricted'} foot={allowed?'Role policy allows exports':'Viewer role cannot export'} color="green"/><Metric icon={ClipboardList} label="Audit events" value={dashboard?.audit_events??'—'} foot="Recorded activity" color="purple"/><Metric icon={ShieldCheck} label="Blocked attempts" value={dashboard?.blocked_attempts??'—'} foot="Authorization denials" color="orange"/></div>
        <div className="content-grid"><section className="panel"><div className="panel-heading"><div><h3>Recent security activity</h3><p>Latest events for your tenant</p></div><button className="text-button" onClick={()=>setPage('Audit Log')}>View all <ArrowUpRight size={14}/></button></div><AuditTable events={dashboard?.recent_events||[]}/></section><section className="panel policy-panel"><div className="panel-heading"><div><h3>Access policy</h3><p>Current authorization context</p></div><ShieldCheck size={20} className="green-icon"/></div><div className="policy-row"><span>Tenant boundary</span><b className="enabled">Enforced</b></div><div className="policy-row"><span>Current role</span><b>{user.role.replace('_',' ')}</b></div><div className="policy-row"><span>Data export</span><b className={allowed?'enabled':'denied'}>{allowed?'Allowed':'Denied'}</b></div><div className="policy-row"><span>Audit logging</span><b className="enabled">Enabled</b></div><div className="policy-note"><LockKeyhole size={16}/><span>Tenant identity is derived from your authenticated session, not from a client-supplied tenant ID.</span></div><button className="primary full" onClick={()=>setPage('Export Center')}>Open Export Center <ArrowUpRight size={16}/></button></section></div>
      </>}
      {page==='Data Records' && <section className="panel full-panel"><div className="panel-heading"><div><h3>Authorized student records</h3><p>Only records belonging to {user.tenant_id} are shown.</p></div><span className="count-pill">{records.length} records</span></div><div className="table-wrap"><table><thead><tr><th>STUDENT ID</th><th>STUDENT NAME</th><th>DEPARTMENT</th><th>YEAR</th><th>ATTENDANCE</th></tr></thead><tbody>{records.map(r=><tr key={r.student_code}><td className="code">{r.student_code}</td><td className="name-cell">{r.student_name}</td><td>{r.department}</td><td>Year {r.year}</td><td><div className="attendance"><span><i style={{width:`${r.attendance_percent}%`}}/></span><b>{r.attendance_percent}%</b></div></td></tr>)}</tbody></table></div><div className="table-foot"><LockKeyhole size={14}/> Tenant isolation enforced on the API for every record query.</div></section>}
      {page==='Export Center' && <div className="export-layout"><section className="panel export-main"><div className="export-hero"><div className="export-hero-icon"><Download size={25}/></div><div><div className="section-kicker">SECURE DATA TRANSFER</div><h2>Export your tenant data</h2><p>Generate a portable report from records you are authorized to access.</p></div></div><div className="export-summary"><div><small>AVAILABLE RECORDS</small><b>{dashboard?.records_available??0}</b></div><div><small>DATA SCOPE</small><b>{user.tenant_id}</b></div><div><small>PERMISSION</small><b className={allowed?'enabled':'denied'}>{allowed?'Granted':'Restricted'}</b></div></div><div className="format-grid"><ExportCard icon={FileSpreadsheet} title="CSV Spreadsheet" desc="Portable comma-separated values file." ext=".csv" onClick={()=>exportFile('csv')} disabled={!allowed||busy}/><ExportCard icon={FileSpreadsheet} title="Excel Workbook" desc="Formatted workbook for analysis." ext=".xlsx" onClick={()=>exportFile('xlsx')} disabled={!allowed||busy}/></div>{!allowed&&<div className="permission-warning"><LockKeyhole size={18}/><div><b>Export permission required</b><p>Your viewer role can inspect authorized records but cannot export them. Sign in as a tenant admin or data manager to test export.</p></div></div>}<div className="export-assurance"><ShieldCheck size={19}/><div><b>Protected at every request</b><p>Authorization is checked by the backend. Changing frontend controls cannot grant export access.</p></div></div></section><section className="panel checklist"><div className="panel-heading"><div><h3>Export safeguards</h3><p>Controls applied to each request</p></div></div>{['Authenticated user required','Tenant scope derived server-side','Role permission checked','Export action written to audit log','Only authorized tenant records included'].map((x,i)=><div className="check-row" key={x}><CheckCircle2 size={17}/><span>{x}</span><b>ON</b></div>)}</section></div>}
      {page==='Audit Log' && <section className="panel full-panel"><div className="panel-heading"><div><h3>Audit trail</h3><p>Security-relevant export activity for {user.tenant_id}</p></div><span className="count-pill">{audit.length} events</span></div><AuditTable events={audit}/><div className="table-foot"><LockKeyhole size={14}/> Audit data is tenant-scoped. Denied export requests are logged before the API returns 403.</div></section>}
      <footer className="footer"><span>© 2026 TenantShield Security Suite</span><span><ShieldCheck size={14}/> Tenant-isolated by design <i/> Hackathon MVP</span></footer>
    </main>
  </div>;
}

function Metric({icon:Icon,label,value,foot,color}){return <div className="metric-card"><div className={`metric-icon ${color}`}><Icon size={19}/></div><div className="metric-label">{label}</div><div className="metric-value">{value}</div><div className="metric-foot"><span className="metric-dot"/> {foot}</div></div>}
function ExportCard({icon:Icon,title,desc,ext,onClick,disabled}){return <div className={`format-card ${disabled?'disabled':''}`}><div className="file-icon"><Icon size={23}/><span>{ext}</span></div><h3>{title}</h3><p>{desc}</p><button className="primary full" onClick={onClick} disabled={disabled}><Download size={16}/> {disabled?'Unavailable':'Generate export'}</button></div>}
function AuditTable({events}){if(!events.length)return <div className="empty-state"><ClipboardList size={25}/><b>No audit events yet</b><span>Export actions and blocked attempts will appear here.</span></div>;return <div className="table-wrap"><table><thead><tr><th>EVENT</th><th>ACTOR</th><th>FORMAT</th><th>RESULT</th><th>TIME / DETAILS</th></tr></thead><tbody>{events.map(e=><tr key={e.id}><td><span className="event-id">EVT-{String(e.id).padStart(4,'0')}</span><div className="event-name">{e.action.replace('_',' ')}</div></td><td>{e.actor_email}</td><td>{e.format?e.format.toUpperCase():'—'}</td><td><span className={`status ${e.outcome==='ALLOWED'?'success':'failure'}`}>{e.outcome==='ALLOWED'?<CheckCircle2 size={13}/>:<XCircle size={13}/>} {e.outcome}</span></td><td><div className="event-time">{e.occurred_at?new Date(e.occurred_at).toLocaleString():'—'}</div><small className="event-detail">{e.details}</small></td></tr>)}</tbody></table></div>}
createRoot(document.getElementById('root')).render(<App/>);
